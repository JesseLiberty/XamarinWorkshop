﻿using System.Windows.Input;
using Xamarin.Forms;

namespace Demo4.ViewModel
{
   public class MainPageViewModel : BaseViewModel
   {
      private string welcomeText = "Hello world";

      public string WelcomeText
      {
         get => welcomeText;
         set => SetValue( ref welcomeText, value );
      }
      public ICommand ButtonClickedCommand { get; set; }

      public MainPageViewModel()
      {
         ButtonClickedCommand = new Command( OnButtonClicked );
      }

      private void OnButtonClicked()
      {
         WelcomeText = "Hello Bound Command!!";
      }
   }

}
