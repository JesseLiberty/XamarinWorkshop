﻿using Demo3.ViewModel;
using System;
using Xamarin.Forms;

namespace Demo3
{
   public partial class MainPage : ContentPage
   {
      private MainPageViewModel vm;
      public MainPage()
      {
         InitializeComponent();
         vm = new MainPageViewModel();
         BindingContext = vm;
      }

      private void ButtonClicked( object sender,
         EventArgs e )
      {
         vm.DisplayText = vm.EntryText;
      }
   }
}
