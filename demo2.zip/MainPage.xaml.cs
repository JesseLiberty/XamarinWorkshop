﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Demo2
{
   public partial class MainPage : ContentPage, INotifyPropertyChanged
   {
      private string welcomeText = "Hello world";

      public string WelcomeText
      {
         get => welcomeText;
         set
         {
            welcomeText = value;
            OnPropChanged();
         }
      }

      public MainPage()
      {
         InitializeComponent();
         BindingContext = this;
      }

      private void ButtonClicked(object sender,
         EventArgs e)
      {
         WelcomeText = "Hello Ohio!!";
      }

      public event PropertyChangedEventHandler PropertyChanged;

      public void OnPropertyChanged(string propertyName)
      {
         PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
      }

      protected void OnPropChanged([CallerMemberName] string propertyName = null)
      {
         PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
      }
   }
}