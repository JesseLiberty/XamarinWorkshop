﻿using Demo5.ViewModel;
using System;
using Xamarin.Forms;

namespace Demo5
{
   public partial class MainPage : ContentPage
   {
      private string name;
      MainPageViewModel vm;
      public MainPage()
      {
         InitializeComponent();
         vm = new MainPageViewModel();
         BindingContext = vm;
      }

      private void Button_OnClicked(object sender, EventArgs e)
      {
         
         Navigation.PushAsync(new Page1(vm.Name));
         
      }
   }
}
