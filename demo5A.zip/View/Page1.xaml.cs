﻿using Demo5.ViewModel;
using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Demo5
{
   [XamlCompilation(XamlCompilationOptions.Compile)]
   public partial class Page1 : ContentPage
   {
      Page1ViewModel vm;

      public Page1(string theName)
      {
         InitializeComponent();
         vm = new Page1ViewModel();
         BindingContext = vm;
         vm.DisplayName = theName;

      }



      private void OnGoBack(object sender, EventArgs e)
      {
         Navigation.PopAsync();
      }
   }
}